configs = {
	'debug':True,
	'db':{
		'host':'127.0.0.1',
		'port':3306,
		'user':'deployment',
		'password':'123456',
		'db':'test'
	},
	'session':{
		'secret':'Awesome'
	}
}