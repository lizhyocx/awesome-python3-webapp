configs = {
	'db':{
		'host':'10.100.21.21'
	}
}